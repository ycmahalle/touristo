import React from "react";
import { Container } from "react-bootstrap";
import { Route, BrowserRouter, Routes } from "react-router-dom";
import Header from "./Components/Header/Header";
import Home from "./Components/Home/Home";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import SearchInput from "./Components/SearchBox/SearchInput";
import AOS from "aos";
import "aos/dist/aos.css"; // You can also use <link> for styles
import Login from "./Components/Login/Login";
import Singlepage from "./Components/SinglePage/Singlepage";
AOS.init();
const App = () => {
  return (
    <>
      <BrowserRouter>
        <Header />
        <Routes>
          <Route exact path="/" element={<Home />} />
          <Route exact path="/login" element={<Login />} />
          <Route exact path="/singlepage" element={<Singlepage />} />
        </Routes>
      </BrowserRouter>
    </>
  );
};

export default App;
