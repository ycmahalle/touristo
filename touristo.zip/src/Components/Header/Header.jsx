import React from 'react'
import "./Header.css";
import Menu from './Navbar/Menu';
const Header = () => {
    return (
        <>
            <Menu />
        </>
    )
}

export default Header