import React from 'react'
import { Navbar, Nav, Container, NavDropdown } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import './menu.css'
const Menu = () => {
    return (
        <>
            <Navbar className='shadow-lg navbarMenu ' expand="lg" >
                <Container>
                    <Navbar.Brand href="#home">
                        <img src="yc.png" alt="Logo" className='rounded-circle shadow-lg' width='50px' />
                    </Navbar.Brand>
                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse id="basic-navbar-nav">
                        <Nav className="me-md-auto mainNav  d-flex align-items-center">
                            <Link to='/' style={{ marginLeft: '12px' }}>Home</Link>
                            <Nav.Link href="#link">Link</Nav.Link>
                        </Nav>
                        <Nav className='mr-auto'>
                            <NavDropdown title="User" id="basic-nav-dropdown">
                                <NavDropdown.Item href="/login">Login / Register</NavDropdown.Item>
                                <NavDropdown.Item href="#action/3.2">Profile</NavDropdown.Item>
                                <NavDropdown.Item href="#action/3.3">Something</NavDropdown.Item>
                                <NavDropdown.Divider />
                                <NavDropdown.Item href="#action/3.4">Separated link</NavDropdown.Item>
                            </NavDropdown>
                        </Nav>
                    </Navbar.Collapse>
                </Container>
            </Navbar>
        </>
    )
}

export default Menu;