import React from 'react'
import './home.css';
import SearchInput from '../SearchBox/SearchInput';
import TouristCard from './TouristCard';
const Home = () => {
    return (
        <>

            <div className="searbox" >
                <SearchInput />
            </div>
            <TouristCard />
        </>
    );
}
export default Home;