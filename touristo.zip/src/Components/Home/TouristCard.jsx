import React, { useState } from 'react'
import { Card, Button, Row, Col, Container } from 'react-bootstrap';
import './card.css';
import { placeData } from '../json/placeData';
import { Singlepage } from "../SinglePage/Singlepage";
import { Link } from 'react-router-dom';
const TouristCard = () => {
    const [Id, setId] = useState({ id: [] })

    const handleSinglePlace = (id) => {
        setId({ id: id });
    };
    const limit = 60;
    return (
        <>
            <Container>
                <div className='homeCards p-4'>
                    <Row>

                        {placeData.map((place, index) => {
                            return (
                                <Col style={{ marginBottom: '12px' }} md='6'>
                                    <Card className='locCard shadow-sm d-flex flex-row' style={{ height: '15rem' }}>
                                        <Card.Img variant="top" src={place.image} className='p-3 w-50' />
                                        <Card.Body className='h-100 p-relative'>
                                            <Card.Title>{place.name}</Card.Title>
                                            <Card.Text >
                                                <Row md="12">
                                                    <p className='' style={{ fontSize: '16px ', textAlign: 'justify' }}>
                                                        {place.about.length > limit ? place.about.substring(0, limit) + '...' : place.about}
                                                    </p>
                                                </Row>
                                            </Card.Text>
                                            <Card.Footer className='d-flex justify-content-center'>
                                                <Button className='cardBtns'>Go</Button>
                                                <Button className='cardBtns favourite'>❤️</Button>
                                                <Button className='cardBtns' onClick={() => handleSinglePlace(place)}>
                                                    {/* <Link to='/singlepage' >...</Link> */}
                                                    <Link to={{ pathname: '/singlepage', data: place }} >...</Link>
                                                </Button>
                                            </Card.Footer>

                                        </Card.Body>
                                    </Card>
                                </Col>
                            )
                        })}

                    </Row>
                </div>
            </Container>
        </>
    )
}

export default TouristCard