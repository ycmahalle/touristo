import React, { useState } from 'react'
import { Container, Form, Button } from 'react-bootstrap'
import './login.css'
const Login = () => {
    const [isRegister, setRegister] = useState(false);
    return (
        <>
            <Container className='d-flex flex-md-row mt-5 justify-content-center align-items-center'>
                {/* */}

                {isRegister ? <div className='Register animate__animated animate__backInUp   shadow-lg w-50 p-3'>
                    <h2 className='text-muted' style={{ borderLeft: '5px solid orange', width: 'fit-content' }}><span style={{ fontSize: '40px', color: 'slateblue', paddingLeft: '5px' }}>R</span>egister</h2>
                    <Form className='w-75 p-2'>
                        <Form.Group className="mb-3" controlId="formBasicEmail">
                            <Form.Label>name</Form.Label>
                            <Form.Control type="name" placeholder="name" />
                        </Form.Group>

                        <Form.Group className="mb-3" controlId="formBasicEmail">
                            <Form.Label>contact</Form.Label>
                            <Form.Control type="contact" placeholder="contact" />
                        </Form.Group>

                        <Form.Group className="mb-3" controlId="formBasicEmail">
                            <Form.Label>Email</Form.Label>
                            <Form.Control type="email" placeholder="email" />
                        </Form.Group>

                        <Form.Group className="mb-3" controlId="formBasicPassword">
                            <Form.Label>Password</Form.Label>
                            <Form.Control type="password" placeholder="Password" />
                        </Form.Group>
                        <Form.Group className="mb-3" controlId="formBasicPassword">
                            <Form.Label>Confirm Password</Form.Label>
                            <Form.Control type="password" placeholder="Confirm Password" />
                        </Form.Group>
                        {/* <Form.Group className="mb-3" controlId="formBasicCheckbox">
                            <Form.Check type="checkbox" label="Check me out" />
                        </Form.Group> */}
                        <Button variant="secondary" className='px-4' type="submit">
                            Register
                        </Button>
                        <br />
                        <br />
                        <button className=' btn  text-danger' onClick={() => setRegister(false)} style={{ borderBottom: '2px solid black' }}>Already Registered | Login!</button>

                    </Form>
                </div> :
                    <div className='Login w-50 p-5 animate__animated animate__backInUp shadow-lg'>
                        <div className="head py-2">
                            <h2 className='text-muted' style={{ borderLeft: '5px solid orange', width: 'fit-content' }}><span style={{ fontSize: '40px', color: 'slateblue', paddingLeft: '5px' }}>L</span>ogin</h2>
                        </div>
                        <Form className='w-75'>
                            <Form.Group className="mb-3" controlId="formBasicEmail">
                                <Form.Label>Username/Email</Form.Label>
                                <Form.Control type="email" placeholder="username" />
                            </Form.Group>

                            <Form.Group className="mb-3" controlId="formBasicPassword">
                                <Form.Label>Password</Form.Label>
                                <Form.Control type="password" placeholder="Password" />
                            </Form.Group>

                            <Button variant="secondary" className='px-4' type="submit">
                                Login
                            </Button>
                            <br />
                            <br />
                            <button className=' btn  text-danger' onClick={() => setRegister(true)} style={{ borderBottom: '2px solid black' }}>Register Yourself!</button>
                        </Form>
                    </div>
                }

            </Container >
        </>
    )
}

export default Login