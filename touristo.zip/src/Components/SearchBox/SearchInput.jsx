import React, { useState } from 'react'
import { Col } from 'react-bootstrap';
import searchData from './Search.json';
const SearchInput = () => {
    const [filteredData, setFiltertedData] = useState([]);
    const searchLocation = (e) => {
        const input = e.target;
        const value = input.value.toLowerCase();

        let filteredResult = searchData.filter((item) => {
            console.log(item.name);
            return item.name.toLowerCase().includes(value);
        });
        if (value === '') {
            setFiltertedData([]);
        } else {
            setFiltertedData(filteredResult);
        }
        console.log('filteredRes >>', filteredResult);

    }
    return (
        <>
            <div className="searchBox m-4 justify-content-center d-flex position-relative ">
                <Col md={6} xs={10}>
                    <input type="search" name='search' onChange={searchLocation} className='form-control' />
                    {filteredData.length !== 0 && <div className="dataResult " >
                        {filteredData.map((i) => {
                            return (<div className="dataItem">
                                {i.name}
                            </div>
                            )
                        })}
                    </div>}
                </Col>
            </div >
        </>
    );
}

export default SearchInput