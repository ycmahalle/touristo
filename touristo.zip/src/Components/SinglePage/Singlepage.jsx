import React, { useState } from 'react'
import { Carousel } from 'react-bootstrap'
import './Singlepage.css'
import { sliderData } from './SliderData'
import { FaArrowCircleLeft, FaArrowCircleRight } from 'react-icons/fa'
const Singlepage = (props) => {
    const [current, setCurrent] = useState(0);
    const length = sliderData.length;
    const nextSlide = () => {
        setCurrent(current === length - 1 ? 0 : current + 1)

    };
    const prevSlide = () => {
        setCurrent(current === 0 ? length - 1 : current - 1)
    }
    console.log(current);
    if (!Array.isArray(sliderData) || sliderData.length <= 0) {
        return null;
    }
    return (
        <>

            Yash
            {console.log(props)}
            {/* {sliderData.map((slide, index) => {

            })} */}
        </>
    )
}

export default Singlepage

{/* <div className="singlePage bg-success">
                <Container className='d-flex justify-content-center'>
                    <FaArrowCircleLeft className='left-arrow' onClick={prevSlide} />
                    <FaArrowCircleRight className='right-arrow' onClick={nextSlide} />
                    <div className="imageSlider">
                        {
                            sliderData.map((slide, index) => {
                                return (
                                    // <div className={index === current ? 'slide active' : 'slide'} key={index + 1}>
                                    //     {index === current &&
                                    //         (<img src={slide.image} className='image' alt="image-slider" srcset="" />)}
                                    // </div>
                                )
                            })
                        }
                    </div>
                </Container>
            </div> */}