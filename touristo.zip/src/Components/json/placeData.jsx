export const placeData = [
    {
        image: 'https://c4.wallpaperflare.com/wallpaper/234/414/551/earth-4k-hd-image-for-wallpaper-thumb.jpg',
        name: 'Chhatri Talav',
        location: 'rathi nagar , Amravati',
        about: `Shades of blue include cyan, navy, turquoise, aqua, midnight blue, sky blue, royal blue, and aquamarine. The base blue color's hex value in HTML is #0000FF.`,
        howToReach: 'by train , by bus then you can take auto from their ',
        accomodation: ' Tata Sumo '
    },
    {
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSctN2rG-zg8-DPW6uqERy070rS7LGvkoQXZA&usqp=CAU',
        name: 'Mahima`s DisneyLand',
        location: 'Mahimas disneyland ,nandgaon peth,Amravati ',
        about: `Shades of blue include cyan, navy, turquoise, aqua, midnight blue, skyturquoise, aqua, midnight blue, sky blue, royal blue, and aquamarine. The base blue color's hex value in HTML is #0000FF.`,
        howToReach: 'by train , by bus then you can take auto from their ',
        accomodation: 'cycle'
    }
]